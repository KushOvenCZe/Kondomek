const express = require('express');
const { WebSocketServer } = require('ws');
const tiktok = require('tiktok-live-connector');
const path = require('path');
const fs = require('fs');
const os = require('os');

// tiktok-live-connector v2 přejmenoval WebcastPushConnection na TikTokLiveConnection
const Connection = tiktok.TikTokLiveConnection || tiktok.WebcastPushConnection;

// Ladicí výpis: při první události každého typu uloží surová data do debug.log (vidíme, co TikTok skutečně posílá).
// Až bude vše fungovat, nastav na false.
const DEBUG = false;

const app = express();
const PORT = 8000;

// --- Nastavení sledování na pozadí ---
// Jak dlouho po odpojení posledního klienta (telefonu) server stream dál sleduje a ukládá události
const KEEP_ALIVE_MS = Number(process.env.TTDASH_KEEP_ALIVE_MS) || 60 * 60 * 1000;
const ENDED_GRACE_MS = 10 * 60 * 1000;          // jak dlouho se pamatuje skončený stream
const BUFFER_MAX = 6000;                        // kolik posledních událostí se ukládá pro později připojené
const RECONNECT_MAX = 8;                        // kolikrát se server po výpadku pokusí připojit znovu
const RECONNECT_BASE_MS = Number(process.env.TTDASH_RECONNECT_MS) || 5000;

app.use(express.static(path.join(__dirname, 'public')));

// --- Údaje z veřejného profilu na TikToku (datum založení, změny jména, region...) ---
// Stahuje se jen na požádání (klik na uživatele v dashboardu). Výsledek se 30 minut pamatuje.
// Pozor: TikTok může dotazy omezit nebo změnit formát stránky; pak dashboard ukáže chybu a ostatní údaje fungují dál.
const profileCache = new Map();   // jméno -> { t, ttl, data }
const profileInflight = new Map();
const PROFILE_TTL_OK = 30 * 60 * 1000;
const PROFILE_TTL_FAIL = 2 * 60 * 1000;

async function loadProfile(name) {
    if (typeof fetch !== 'function') return { ok: false, error: 'Tato verze Node.js nemá fetch (potřeba Node 18 nebo novější).' };
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 10000);
    try {
        const res = await fetch(`https://www.tiktok.com/@${encodeURIComponent(name)}`, {
            signal: ctrl.signal,
            headers: {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
                'Accept': 'text/html,application/xhtml+xml',
                'Accept-Language': 'en-US,en;q=0.9'
            }
        });
        if (!res.ok) return { ok: false, error: `TikTok vrátil HTTP ${res.status}.` };
        const html = await res.text();
        const m = html.match(/<script[^>]*id="__UNIVERSAL_DATA_FOR_REHYDRATION__"[^>]*>([\s\S]*?)<\/script>/);
        if (!m) return { ok: false, error: 'TikTok nevrátil údaje o profilu (omezení dotazů nebo ověření, že nejste robot).' };
        const scope = JSON.parse(m[1]).__DEFAULT_SCOPE__ || {};
        const info = scope['webapp.user-detail'] && scope['webapp.user-detail'].userInfo;
        if (!info || !info.user) return { ok: false, error: 'Profil nenalezen nebo není dostupný.' };
        const u = info.user, s = info.stats || {};
        const n = (x) => { const v = Number(x); return Number.isFinite(v) ? v : undefined; };
        return {
            ok: true,
            createTime: n(u.createTime),
            nickNameModifyTime: n(u.nickNameModifyTime),
            uniqueIdModifyTime: n(u.uniqueIdModifyTime),
            region: u.region || undefined,
            language: u.language || undefined,
            verified: Boolean(u.verified),
            privateAccount: Boolean(u.privateAccount),
            ttSeller: Boolean(u.ttSeller),
            signature: u.signature || undefined,
            bioLink: (u.bioLink && u.bioLink.link) || undefined,
            stats: {
                followers: n(s.followerCount), following: n(s.followingCount), friends: n(s.friendCount),
                hearts: n(first(s.heartCount, s.heart)), videos: n(s.videoCount)
            }
        };
    } catch (e) {
        return { ok: false, error: e && e.name === 'AbortError' ? 'TikTok neodpověděl do 10 s.' : `Dotaz selhal: ${e && e.message ? e.message : e}` };
    } finally {
        clearTimeout(timer);
    }
}
function first(...vals) { return vals.find(v => v !== undefined && v !== null && v !== ''); }

app.get('/api/profile/:name', async (req, res) => {
    const name = String(req.params.name || '').replace(/^@/, '');
    if (!/^[A-Za-z0-9._]{1,40}$/.test(name)) return res.status(400).json({ ok: false, error: 'Neplatné uživatelské jméno.' });
    const key = name.toLowerCase();
    const hit = profileCache.get(key);
    if (hit && Date.now() - hit.t < hit.ttl) return res.json(hit.data);
    if (!profileInflight.has(key)) {
        profileInflight.set(key, loadProfile(name).then((data) => {
            profileCache.set(key, { t: Date.now(), ttl: data.ok ? PROFILE_TTL_OK : PROFILE_TTL_FAIL, data });
            return data;
        }).finally(() => profileInflight.delete(key)));
    }
    res.json(await profileInflight.get(key));
});

const server = app.listen(PORT, "127.0.0.1", () => {
    console.log(`\n=========================================`);
    console.log(`🚀 PRO Server běží na http://localhost:${PORT}`);
    const ips = [];
    for (const list of Object.values(os.networkInterfaces())) {
        for (const n of list || []) {
            if ((n.family === 'IPv4' || n.family === 4) && !n.internal) ips.push(n.address);
        }
    }
    console.log(`📱 Na telefonu (stejná Wi-Fi): ${ips.length ? ips.map(ip => `http://${ip}:${PORT}`).join('   nebo   ') : 'adresu zjistíte příkazem ipconfig'}`);
    console.log(`=========================================\n`);
});

server.on('error', (err) => {
    if (err.code === 'EADDRINUSE') {
        console.error(`❌ Port ${PORT} je už obsazený. Zavři starou instanci serveru a zkus to znovu.`);
    } else {
        console.error('❌ Chyba serveru:', err);
    }
    process.exit(1);
});

// Ať jedna chyba z knihovny neshodí celý server
process.on('unhandledRejection', (err) => console.error('⚠️ Neošetřená chyba:', err));
process.on('uncaughtException', (err) => console.error('⚠️ Neočekávaná chyba:', err));

const wss = new WebSocketServer({ server });

// ---------------------------------------------------------------------------
// Pomocné funkce pro data o uživateli
// ---------------------------------------------------------------------------
const jsonSafe = (v) => {
    try { return JSON.stringify(v, (k, x) => typeof x === 'bigint' ? x.toString() : x) || ''; } catch (e) { return ''; }
};
const toNum = (x) => {
    if (x === undefined || x === null) return undefined;
    const n = Number(typeof x === 'object' ? x.toString() : x);
    return Number.isFinite(n) ? n : undefined;
};
const badgeLabel = (b) => {
    if (typeof b === 'string') return b;
    if (!b || typeof b !== 'object') return '';
    const text = b.text && (b.text.defaultPattern || (b.text.defaultFormat && b.text.defaultFormat.defaultPattern));
    const label = first(b.name, b.type, b.displayType, b.combine && b.combine.str, text);
    return typeof label === 'string' ? label : '';
};
// Vezmeme pouze číselnou úroveň z pole, které ji výslovně označuje.
const findLevel = (o, depth = 0) => {
    if (!o || typeof o !== 'object' || depth > 5) return undefined;
    for (const [k, v] of Object.entries(o)) {
        if (/(?:level|grade|fanclublevel|gifterlevel)/i.test(k)) {
            const n = toNum(v);
            if (n !== undefined && n >= 0 && n <= 1000) return n;
        }
    }
    for (const v of Object.values(o)) {
        if (v && typeof v === 'object') {
            const r = findLevel(v, depth + 1);
            if (r !== undefined) return r;
        }
    }
    return undefined;
};
const classifyBadge = (b) => {
    const t = badgeLabel(b);
    const obj = b && typeof b === 'object' ? b : {};
    const json = (typeof b === 'string' ? b : jsonSafe(b)).toLowerCase();
    let k = 'other';
    if (/moderator|pm_mt_moderator/.test(json)) k = 'mod';
    else if (/subscriber|subscription/.test(json)) k = 'sub';
    else if (/gifter|gift_level|paygrade|pay_grade/.test(json) || /^\d{1,3}$/.test(t)) k = 'gifter';
    else if (/fansclub|fanclub|fan_club|fans_club|team_member|fanclubname/.test(json)) k = 'fan';
    const lv = k === 'gifter' && /^\d{1,3}$/.test(t) ? Number(t) : findLevel(obj);
    // Nesmíme odhadovat typ odznaku pouze z čísla úrovně.
    const fallback = k === 'mod' ? 'Moderátor' : k === 'sub' ? 'Předplatitel' :
        k === 'gifter' ? 'Dárce' : k === 'fan' ? 'Fanklub' : 'Neurčený odznak';
    return {
        t: t || fallback, k,
        ty: String(first(obj.type, obj.displayType) || ''),
        sc: obj.badgeSceneType !== undefined ? toNum(obj.badgeSceneType) : undefined,
        lv
    };
};

// Podporuje starý (data.nickname) i nový formát (data.user.nickname).
// Co TikTok neposlal, zůstane undefined a dashboard to prostě nezobrazí.
const getUser = (data) => {
    const u = data.user || data;
    const rawBadges = [].concat(...[u.userBadges, data.userBadges, u.badges, data.badges].filter(Array.isArray));
    const badgeJson = rawBadges.map(b => jsonSafe(b).toLowerCase());
    const badgeList = [];
    rawBadges.map(classifyBadge).filter(x => x.t).forEach(x => { if (!badgeList.some(y => y.t === x.t && y.k === x.k)) badgeList.push(x); });
    const gifterBadge = badgeList.find(x => x.k === 'gifter');
    const fanBadge = badgeList.find(x => x.k === 'fan');
    // Legacy PC connector: a bare numeric badge label is a gifter level.
    // Unknown badges with Lv.N remain unclassified until source metadata confirms the type.
    const fan = (u.fansClub && (u.fansClub.data || u.fansClub)) || (data.fansClub && (data.fansClub.data || data.fansClub));
    const avatar = first(
        u.profilePictureUrl, data.profilePictureUrl,
        u.profilePicture && (u.profilePicture.url || (u.profilePicture.urls && u.profilePicture.urls[0])),
        u.avatarThumb && u.avatarThumb.urlList && u.avatarThumb.urlList[0]
    );
    return {
        id: String(first(u.userId, data.userId, u.uniqueId, data.uniqueId) || 'neznamy'),
        uniqueId: first(u.uniqueId, data.uniqueId),
        nick: first(u.nickname, data.nickname, u.uniqueId, data.uniqueId) || 'Neznámý',
        avatar: avatar,
        // Moderátor se pozná podle odznaku (pm_mt_moderator_im), starý příznak isModerator je jen záloha
        admin: Boolean(u.isModerator || data.isModerator || badgeJson.some(j => j.includes('moderator'))),
        sub: Boolean(u.isSubscriber || data.isSubscriber || badgeJson.some(j => j.includes('subscriber') || j.includes('subscription'))),
        followRole: toNum(first(u.followRole, data.followRole)),
        badges: badgeList,
        gifterLevel: toNum(first(u.gifterLevel, data.gifterLevel, u.payGrade && u.payGrade.level, data.payGrade && data.payGrade.level, gifterBadge && gifterBadge.lv)),
        topGifterRank: toNum(first(u.topGifterRank, data.topGifterRank)),
        newGifter: Boolean(u.isNewGifter || data.isNewGifter),
        fanLevel: toNum(first(fan && fan.level, fan && fan.fansLevel, u.teamMemberLevel, data.teamMemberLevel, fanBadge && fanBadge.lv)),
        fanName: first(fan && fan.clubName, fan && fan.fansClubName, fanBadge && fanBadge.t !== 'Fanklub' && fanBadge.t),
        followers: toNum(u.followInfo && u.followInfo.followerCount),
        following: toNum(u.followInfo && u.followInfo.followingCount),
        bio: first(u.bioDescription, data.bioDescription),
        created: toNum(first(u.createTime, u.create_time)),
        nickChanged: toNum(first(u.nickNameUpdateTime, u.nicknameUpdateTime, u.nickname_update_time))
    };
};

// ---------------------------------------------------------------------------
// Ladicí výpis (debug.log)
// ---------------------------------------------------------------------------
const debugLogged = new Set();
let debugMaxBadges = 0, debugRich = 0;
function debugWrite(text) {
    try { fs.appendFileSync(path.join(__dirname, 'debug.log'), `[${new Date().toISOString()}] ${text}\n\n`); } catch (e) { /* ladicí výpis nesmí shodit server */ }
}
function attachDebug(conn) {
    // Surová data první události každého typu
    ['chat', 'member', 'gift', 'like', 'follow', 'share', 'questionNew'].forEach((ev) => {
        conn.on(ev, (data) => {
            if (debugLogged.has(ev)) return;
            debugLogged.add(ev);
            debugWrite(`${ev}: ${jsonSafe(data).slice(0, 8000)}`);
        });
    });
    // Celá surová data chatu u uživatelů s nejvíc odznaky (dárce, fanklub...), ať vidíme, kde TikTok posílá úrovně
    conn.on('chat', (data) => {
        const n = getUser(data).badges.length;
        if (n <= debugMaxBadges || debugRich >= 5) return;
        debugMaxBadges = n; debugRich++;
        debugWrite(`chat s ${n} odznaky: ${jsonSafe(data).slice(0, 12000)}`);
    });
}

// ---------------------------------------------------------------------------
// Sledování streamu na pozadí
//
// Spojení s TikTokem drží SERVER, ne prohlížeč/telefon. Když se klient (telefon) odpojí, server stream dál sleduje
// a ukládá posledních BUFFER_MAX událostí. Po připojení se klientovi přehrají, takže mu nic neuteče.
// Server se po výpadku spojení sám znovu připojí a nepoužívanou session po KEEP_ALIVE_MS zruší.
// ---------------------------------------------------------------------------
const BUFFERED = new Set(['chat', 'join', 'gift', 'event', 'like']);
const ARCHIVE_DIR = path.join(__dirname, 'event_archive_v3');
const RETENTION_MS = 30 * 86400000;
const diagnostics = [];
const metrics = { received: 0, stored: 0, writeErrors: 0, lastEvent: null, reconnects: 0 };
let sequence = 0;
fs.mkdirSync(ARCHIVE_DIR, { recursive: true });
function diagnose(level, area, message) {
    const record = { ts: Date.now(), level, area, message: String(message).slice(0, 800) };
    diagnostics.push(record);
    if (diagnostics.length > 250) diagnostics.shift();
    if (level === 'error') console.error('[diagnostika]', area, record.message);
}
function safeName(name) { return name.toLowerCase().replace(/[^a-z0-9._]/g, '_'); }
function archiveFile(s) { return path.join(ARCHIVE_DIR, safeName(s.username), s.archiveId + '.jsonl'); }
function cleanArchive() {
    const cutoff = Date.now() - RETENTION_MS;
    try {
        for (const account of fs.readdirSync(ARCHIVE_DIR)) {
            const dir = path.join(ARCHIVE_DIR, account);
            if (!fs.statSync(dir).isDirectory()) continue;
            for (const name of fs.readdirSync(dir)) {
                if (!name.endsWith('.jsonl')) continue;
                const full = path.join(dir, name);
                if (fs.statSync(full).mtimeMs < cutoff) fs.unlinkSync(full);
            }
        }
    } catch (err) { diagnose('error', 'archive-cleanup', err.message); }
}
cleanArchive();
const cleanupTimer = setInterval(cleanArchive, 6 * 3600000);
if (cleanupTimer.unref) cleanupTimer.unref();
function appendJournal(s, data) {
    metrics.received++;
    metrics.lastEvent = Date.now();
    const filename = archiveFile(s);
    const line = JSON.stringify(data) + '\n';
    s.writeQueue = (s.writeQueue || Promise.resolve()).then(async () => {
        await fs.promises.mkdir(path.dirname(filename), { recursive: true });
        await fs.promises.appendFile(filename, line);
        metrics.stored++;
    }).catch(err => { metrics.writeErrors++; diagnose('error', 'archive', err.message); });
}
function listArchives() {
    const result = [];
    for (const account of fs.readdirSync(ARCHIVE_DIR)) {
        const dir = path.join(ARCHIVE_DIR, account);
        if (!fs.statSync(dir).isDirectory()) continue;
        for (const filename of fs.readdirSync(dir)) {
            if (!filename.endsWith('.jsonl')) continue;
            const stat = fs.statSync(path.join(dir, filename));
            result.push({ account, file: filename, bytes: stat.size, modified: stat.mtimeMs });
        }
    }
    return result.sort((a,b) => b.modified-a.modified);
}
app.get('/api/diagnostics', (req, res) => res.json({ ok: true, metrics, sessions: [...sessions.values()].map(s => ({ username:s.username, connected: !!s.connected, retries:s.retries, clients:s.clients.size, ended:s.ended })), errors: diagnostics.slice(-70) }));
app.get('/api/archives', (req, res) => { try { res.json({ ok:true, retentionDays:30, files:listArchives() }); } catch(err) { res.status(500).json({ok:false,error:err.message}); } });
app.get('/api/archive/export', (req,res) => {
    const account=String(req.query.account||''), file=String(req.query.file||'');
    if (!/^[a-z0-9._]{1,40}$/.test(account) || !/^\d{13}_[a-z0-9]+\.jsonl$/.test(file)) return res.status(400).end('Invalid file');
    const full=path.join(ARCHIVE_DIR,account,file);
    if (!fs.existsSync(full)) return res.status(404).end('Not found');
    res.setHeader('Content-Type','application/x-ndjson; charset=utf-8');
    res.setHeader('Content-Disposition',`attachment; filename="${file}"`);
    fs.createReadStream(full).pipe(res);
});
app.get('/api/diagnostics/export', (req,res) => {
    res.setHeader('Content-Type','application/json; charset=utf-8');
    res.setHeader('Content-Disposition','attachment; filename="kushoven-diagnostika.json"');
    res.json({ version:'3.0', time:new Date().toISOString(), metrics, errors:diagnostics.slice(-100) });
});

// --- Kondomek: AI duch, který mluví za streamera (viz kondomek.js) ---
const kondomek = require('./kondomek')({ app, express, dir: __dirname, getUser: (d) => getUser(d), diagnose });

const sessions = new Map();   // malé písmeno jména -> session

function createSession(username) {
    const s = {
        username: username, key: username.toLowerCase(),
        clients: new Set(), buffer: [], last: {}, conn: null, archiveId: `${Date.now()}_${Math.random().toString(36).slice(2,8)}`, connected: false,
        closed: false, ended: false, endedAt: 0, retries: 0, idleTimer: null,
        likes: 0, viewers: 0
    };
    // Pošle zprávu všem připojeným klientům a (podle typu) si ji uloží pro později připojené
    s.send = (data) => {
        data.ts = Date.now();
        if (BUFFERED.has(data.type)) data.id = `${s.archiveId}:${++sequence}`;
        if (BUFFERED.has(data.type)) {
            s.buffer.push(data);
            if (s.buffer.length > BUFFER_MAX) {
                const i = s.buffer.findIndex(m => m.type === 'join');   // nejdřív zahazujeme nejstarší "připojil se"
                s.buffer.splice(i >= 0 ? i : 0, 1);
            }
        } else {
            s.last[data.type] = data;
            if (data.type === 'connect') delete s.last.error;
        }
        // Archivujeme i stavové události, nejen chat a dárky.
        appendJournal(s, data);
        const json = JSON.stringify(data);
        for (const ws of s.clients) {
            if (ws.readyState === ws.OPEN) ws.send(json);
        }
    };
    startConnection(s, false);
    return s;
}

function closeSession(s) {
    s.closed = true;
    clearTimeout(s.idleTimer);
    try { if (s.conn) s.conn.disconnect(); } catch (e) { /* už odpojeno */ }
    if (sessions.get(s.key) === s) sessions.delete(s.key);
}

function getSession(username) {
    const key = username.toLowerCase();
    let s = sessions.get(key);
    // Skončený stream si chvíli pamatujeme (ať jde dohledat, co se stalo), pak začne nová session
    if (s && s.ended && Date.now() - s.endedAt > ENDED_GRACE_MS) { closeSession(s); s = null; }
    if (!s) {
        s = createSession(username);
        sessions.set(key, s);
    }
    return s;
}

function scheduleReconnect(s) {
    if (s.closed || s.ended) return;
    if (s.retries >= RECONNECT_MAX) {
        s.send({ type: 'error', message: 'Spojení s TikTokem se nepodařilo obnovit.' });
        s.ended = true; s.endedAt = Date.now();
        return;
    }
    s.retries++; metrics.reconnects++;
    const timer = setTimeout(() => {
        if (s.closed || s.ended) return;
        console.log(`🔄 Obnovuji spojení (${s.retries}/${RECONNECT_MAX}): ${s.username}`);
        startConnection(s, true);
    }, RECONNECT_BASE_MS * s.retries);
    if (timer.unref) timer.unref();
}

function startConnection(s, isRetry) {
    const conn = new Connection(s.username, { clientLanguage: 'cs-CZ' });
    s.conn = conn;
    kondomek.attach(conn, s);
    let dropped = false;
    const onDrop = () => {
        if (dropped) return;
        dropped = true;
        if (s.conn === conn) scheduleReconnect(s);
    };

    conn.on('connected', (state) => {
        console.log(`🔗 Připojeno k: ${s.username}`);
        s.connected = true; diagnose('info','tiktok',`Připojeno: ${s.username}`);
        s.retries = 0;
        const roomInfo = (state && state.roomInfo) || conn.roomInfo || {};
        if (roomInfo.stats) {
            s.likes = Number(roomInfo.stats.likeCount) || s.likes;
            s.viewers = Number(roomInfo.stats.totalUser) || s.viewers;
        }
        s.send({ type: 'connect', totalLikes: s.likes, totalViewers: s.viewers });
    });

    conn.on('roomUser', (data) => s.send({ type: 'viewer_count', count: Number(data.viewerCount) || 0 }));

    conn.on('member', (data) => {
        s.viewers++;
        s.send({ type: 'join', totalViewers: s.viewers, user_data: getUser(data) });
    });

    conn.on('like', (data) => {
        // totalLikeCount je přesnější než ruční sčítání
        if (data.totalLikeCount != null && Number(data.totalLikeCount) > 0) {
            s.likes = Number(data.totalLikeCount);
        } else {
            s.likes += Number(data.likeCount) || 0;
        }
        s.send({ type: 'like', totalLikes: s.likes, count: Number(data.likeCount) || 0, user_data: getUser(data) });
    });

    conn.on('chat', (data) => s.send({ type: 'chat', comment: data.comment || '', user_data: getUser(data) }));

    // Sledování a sdílení mají vlastní události (původní 'social' by je hlásil dvakrát)
    conn.on('follow', (data) => s.send({ type: 'event', kind: 'follow', action: 'začal/a sledovat tvůrce ❤️', user_data: getUser(data) }));
    conn.on('share', (data) => s.send({ type: 'event', kind: 'share', action: 'sdílel/a stream 🔗', user_data: getUser(data) }));


    conn.on('streamEnd', () => {
        diagnose('info','tiktok',`LIVE ukončen: ${s.username}`);
        s.send({ type: 'error', message: 'Stream byl ukončen.' });
        s.ended = true; s.endedAt = Date.now();
    });
    conn.on('error', (err) => {
        console.error('⚠️ Chyba spojení:', err && err.message ? err.message : err);
        diagnose('error','tiktok', String((err && err.message) || err));
        s.send({ type: 'error', message: String((err && err.message) || err) });
    });
    conn.on('disconnected', () => {
        console.log(`🔌 Odpojeno: ${s.username}`);
        s.connected = false; diagnose('warn','tiktok',`Odpojeno: ${s.username}`);
        onDrop();
    });

    if (DEBUG) attachDebug(conn);

    conn.connect().catch((err) => {
        console.error(`❌ Nepodařilo se připojit k ${s.username}:`, err && err.message ? err.message : err);
        if (isRetry) { onDrop(); return; }
        dropped = true;
        s.send({ type: 'error', message: 'Uživatel neexistuje nebo není LIVE.' });
        closeSession(s);   // další pokus o připojení začne znovu
    });
}

// Novému klientovi přehraje, co se stalo (zprávy mají replay: true, ať dashboard nespouští upozornění)
function replay(s, ws) {
    const out = (m) => { if (ws.readyState === ws.OPEN) ws.send(JSON.stringify(Object.assign({}, m, { replay: true }))); };
    if (s.last.connect) out(s.last.connect);
    s.buffer.forEach(out);
    ['viewer_count', 'error'].forEach((t) => { if (s.last[t]) out(s.last[t]); });
}

wss.on('connection', (ws, req) => {
    // Okýnko s Kondomkem má vlastní kanál
    if ((req.url || '').startsWith('/_kondomek')) {
        ws.isAlive = true;
        ws.on('pong', () => { ws.isAlive = true; });
        kondomek.handleSocket(ws);
        return;
    }
    let username = '';
    try {
        username = decodeURIComponent((req.url || '').split('?')[0].split('/').pop() || '');
    } catch (e) {
        username = '';
    }
    username = username.replace('@', '').trim();

    const sendSafe = (data) => {
        if (ws.readyState === ws.OPEN) ws.send(JSON.stringify(data));
    };

    if (!username || username === 'ws' || !/^[A-Za-z0-9._]{1,40}$/.test(username)) {
        sendSafe({ type: 'error', message: 'Chybí nebo je neplatné uživatelské jméno.' });
        ws.close();
        return;
    }

    ws.isAlive = true;
    ws.on('pong', () => { ws.isAlive = true; });

    // "hello" nese čas serveru, aby dashboard správně zobrazil čas přehrávaných událostí
    sendSafe({ type: 'hello', now: Date.now() });

    const s = getSession(username);
    clearTimeout(s.idleTimer);
    s.clients.add(ws);
    replay(s, ws);

    ws.on('close', () => {
        s.clients.delete(ws);
        if (!s.clients.size && !s.closed) {
            // Nikdo není připojený: server stream dál sleduje, dokud nevyprší KEEP_ALIVE_MS
            clearTimeout(s.idleTimer);
            s.idleTimer = setTimeout(() => {
                console.log(`💤 Nikdo se nepřipojil, přestávám sledovat: ${s.username}`);
                closeSession(s);
            }, KEEP_ALIVE_MS);
            if (s.idleTimer.unref) s.idleTimer.unref();
        }
    });
    ws.on('error', (err) => console.error('⚠️ Chyba WebSocketu:', err.message));
});

// Mobilní sítě umí tiše zahodit nečinné spojení; pravidelný ping zjistí mrtvé klienty
const heartbeat = setInterval(() => {
    (wss.clients || []).forEach((ws) => {
        if (ws.isAlive === false) return ws.terminate();
        ws.isAlive = false;
        try { ws.ping(); } catch (e) { /* ignore */ }
    });
}, 30000);
if (heartbeat.unref) heartbeat.unref();
