package cz.kushoven.dashboard;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.*;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import java.io.File;
import java.util.Locale;

/**
 * Kondomek – plovoucí okýnko s duchem přes ostatní aplikace (hru).
 * Ukazuje stránku ghost.html z lokálního serveru a čte věty hlasem telefonu.
 * Hlas se nejdřív uloží do souboru a přehraje přes MediaPlayer této aplikace,
 * aby ho zachytil i záznam obrazovky / TikTok LIVE (zvuk médií).
 * Okýnko jde posouvat prstem. Ovládání je v oznámení (skrýt/ukázat, vypnout).
 */
public class OverlayService extends Service {
    static final String ACTION_STOP = "cz.kushoven.dashboard.KONDOMEK_STOP";
    static final String ACTION_TOGGLE = "cz.kushoven.dashboard.KONDOMEK_TOGGLE";
    static final String CHANNEL = "kondomek";
    static volatile boolean running = false;
    static volatile String ttsStatus = "Hlas se teprve spouští…";

    private final Handler ui = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private FrameLayout box;
    private WebView web;
    private WindowManager.LayoutParams lp;
    private TextToSpeech tts;
    private volatile boolean ttsReady = false;
    private MediaPlayer player;
    private String playingId = null;
    private String size = "M";
    private boolean hidden = false;

    @Override public void onCreate() {
        super.onCreate();
        running = true;
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Kondomek (AI duch)", NotificationManager.IMPORTANCE_LOW));
        Notification n = buildNotification();
        if (Build.VERSION.SDK_INT >= 34) startForeground(3, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(3, n);
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Kondomek potřebuje povolení „Zobrazit přes jiné aplikace“.", Toast.LENGTH_LONG).show();
            stopSelf();
            return;
        }
        size = getSharedPreferences("dashboard", MODE_PRIVATE).getString("kondomek_size", "M");
        initTts();
        createWindow();
    }

    private Notification buildNotification() {
        int flags = PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT;
        PendingIntent toggle = PendingIntent.getService(this, 31, new Intent(this, OverlayService.class).setAction(ACTION_TOGGLE), flags);
        PendingIntent stop = PendingIntent.getService(this, 32, new Intent(this, OverlayService.class).setAction(ACTION_STOP), flags);
        PendingIntent open = PendingIntent.getActivity(this, 33, new Intent(this, MainActivity.class), flags);
        return new Notification.Builder(this, CHANNEL)
                .setContentTitle("👻 Kondomek je na obrazovce")
                .setContentText("Posouvej ho prstem. Skrýt nebo vypnout můžeš tady.")
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setContentIntent(open)
                .addAction(new Notification.Action.Builder(null, "Skrýt / ukázat", toggle).build())
                .addAction(new Notification.Action.Builder(null, "Vypnout", stop).build())
                .setOngoing(true).build();
    }

    // ------------------------------------------------------------------ hlas
    private void initTts() {
        tts = new TextToSpeech(this, status -> {
            if (status != TextToSpeech.SUCCESS) { ttsStatus = "❌ Hlas v telefonu nejde spustit."; return; }
            int r = tts.setLanguage(new Locale("cs", "CZ"));
            if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
                ttsStatus = "⚠️ Chybí český hlas. Nainstaluj ho: Nastavení › Převod textu na řeč (doporučeno Google).";
                return;
            }
            tts.setPitch(1.2f);
            tts.setSpeechRate(1.05f);
            tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                @Override public void onStart(String id) { }
                @Override public void onDone(String id) { ui.post(() -> play(id)); }
                @Override public void onError(String id) { js("error", id); }
            });
            ttsReady = true;
            ttsStatus = "✅ Český hlas připraven (" + tts.getDefaultEngine() + ")";
        });
    }

    private File voiceFile(String id) { return new File(getCacheDir(), "kondomek_" + id + ".wav"); }

    private void play(String id) {
        stopPlayer();
        File f = voiceFile(id);
        if (!f.isFile()) { js("error", id); return; }
        try {
            player = new MediaPlayer();
            playingId = id;
            player.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build());
            player.setDataSource(f.getAbsolutePath());
            player.setOnPreparedListener(p -> { p.start(); js("start", id); });
            player.setOnCompletionListener(p -> { stopPlayer(); f.delete(); js("done", id); });
            player.setOnErrorListener((p, w, e) -> { stopPlayer(); f.delete(); js("error", id); return true; });
            player.prepareAsync();
        } catch (Exception e) {
            stopPlayer();
            js("error", id);
        }
    }

    private void stopPlayer() {
        if (player != null) { try { player.stop(); } catch (Exception ignored) { } player.release(); player = null; }
        playingId = null;
    }

    private void js(String event, String id) {
        final String safeId = id == null ? "0" : id.replaceAll("[^0-9]", "");
        ui.post(() -> { if (web != null) web.evaluateJavascript("window.kondomekSpeech&&window.kondomekSpeech('" + event + "','" + safeId + "')", null); });
    }

    private class TtsBridge {
        @JavascriptInterface public void speak(String id, String text) {
            if (!ttsReady || text == null || id == null) { js("error", id); return; }
            Bundle b = new Bundle();
            b.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, id);
            int r = tts.synthesizeToFile(text, b, voiceFile(id), id);
            if (r != TextToSpeech.SUCCESS) js("error", id);
        }
        @JavascriptInterface public void stop() { ui.post(() -> { if (tts != null) tts.stop(); stopPlayer(); }); }
        @JavascriptInterface public void setSize(String s) { ui.post(() -> applySize(s)); }
        @JavascriptInterface public String status() { return ttsStatus; }
    }

    // ------------------------------------------------------------------ okýnko
    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private int[] sizeFor(String s) {
        if ("S".equals(s)) return new int[]{dp(150), dp(200)};
        if ("L".equals(s)) return new int[]{dp(280), dp(370)};
        return new int[]{dp(210), dp(280)};
    }

    private void applySize(String s) {
        if (s == null || !s.matches("[SML]") || box == null) return;
        size = s;
        getSharedPreferences("dashboard", MODE_PRIVATE).edit().putString("kondomek_size", s).apply();
        int[] wh = sizeFor(s);
        lp.width = wh[0]; lp.height = wh[1];
        try { wm.updateViewLayout(box, lp); } catch (Exception ignored) { }
    }

    private void createWindow() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        SharedPreferences prefs = getSharedPreferences("dashboard", MODE_PRIVATE);
        int[] wh = sizeFor(size);
        lp = new WindowManager.LayoutParams(wh[0], wh[1],
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = prefs.getInt("kondomek_x", dp(16));
        lp.y = prefs.getInt("kondomek_y", dp(120));

        box = new FrameLayout(this);
        web = new WebView(this);
        web.setBackgroundColor(Color.TRANSPARENT);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        web.addJavascriptInterface(new TtsBridge(), "KondomekTTS");
        web.setWebViewClient(new WebViewClient() {
            @Override public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                // Server ještě neběží → zkusíme to za chvíli znovu
                if (r.isForMainFrame()) ui.postDelayed(() -> { if (web != null) web.reload(); }, 2500);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) { return true; }
        });
        web.setVerticalScrollBarEnabled(false);
        web.setHorizontalScrollBarEnabled(false);
        web.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy; float tx, ty;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN: sx = lp.x; sy = lp.y; tx = e.getRawX(); ty = e.getRawY(); return true;
                    case MotionEvent.ACTION_MOVE:
                        lp.x = sx + Math.round(e.getRawX() - tx);
                        lp.y = sy + Math.round(e.getRawY() - ty);
                        try { wm.updateViewLayout(box, lp); } catch (Exception ignored) { }
                        return true;
                    case MotionEvent.ACTION_UP:
                        getSharedPreferences("dashboard", MODE_PRIVATE).edit().putInt("kondomek_x", lp.x).putInt("kondomek_y", lp.y).apply();
                        return true;
                }
                return true;
            }
        });
        box.addView(web, new FrameLayout.LayoutParams(-1, -1));
        wm.addView(box, lp);
        web.loadUrl("http://127.0.0.1:8000/ghost.html?bg=0");
    }

    @Override public int onStartCommand(Intent i, int flags, int id) {
        String a = i != null ? i.getAction() : null;
        if (ACTION_STOP.equals(a)) { stopSelf(); return START_NOT_STICKY; }
        if (ACTION_TOGGLE.equals(a) && box != null) {
            hidden = !hidden;
            box.setVisibility(hidden ? View.GONE : View.VISIBLE);
            if (hidden) { if (tts != null) tts.stop(); stopPlayer(); }
        }
        if (i != null && i.hasExtra("size")) applySize(i.getStringExtra("size"));
        return START_NOT_STICKY;
    }

    @Override public void onDestroy() {
        running = false;
        ui.removeCallbacksAndMessages(null);
        stopPlayer();
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (box != null) { try { wm.removeView(box); } catch (Exception ignored) { } }
        if (web != null) web.destroy();
        web = null; box = null;
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent i) { return null; }
}
