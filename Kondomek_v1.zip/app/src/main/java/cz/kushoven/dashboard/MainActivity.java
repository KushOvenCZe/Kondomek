package cz.kushoven.dashboard;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import java.net.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
 private static final int EXPORT_REQUEST=904;
 private String exportPath="";
 private static final String HOME="http://127.0.0.1:8000/";
 private final ExecutorService checker=Executors.newSingleThreadExecutor();
 private WebView web;
 private TextView status;
 private volatile boolean closed=false;
 private boolean checking=false, loadFailed=false;
 private final Handler handler=new Handler(Looper.getMainLooper());
 private final android.content.SharedPreferences.OnSharedPreferenceChangeListener listener=(prefs,key)->{};

 @Override public void onCreate(Bundle saved){
  super.onCreate(saved);
        // Respect Android status bar and gesture navigation areas.
        if (android.os.Build.VERSION.SDK_INT >= 35) {
            getWindow().getDecorView().setOnApplyWindowInsetsListener((view, insets) -> {
                android.graphics.Insets bars = insets.getInsets(
                    android.view.WindowInsets.Type.statusBars()
                    | android.view.WindowInsets.Type.navigationBars()
                );
                view.setPadding(bars.left, bars.top, bars.right, bars.bottom);
                return insets;
            });
        }

  getWindow().setStatusBarColor(Color.rgb(13,16,19));
  getWindow().setNavigationBarColor(Color.rgb(13,16,19));
  FrameLayout root=new FrameLayout(this);root.setBackgroundColor(Color.rgb(13,16,19));
  web=new WebView(this);web.setVisibility(View.INVISIBLE);web.setBackgroundColor(Color.rgb(13,16,19));
  WebSettings cfg=web.getSettings();cfg.setJavaScriptEnabled(true);cfg.setDomStorageEnabled(true);
  cfg.setAllowFileAccess(false);cfg.setAllowContentAccess(false);
  web.addJavascriptInterface(new Bridge(),"AndroidBridge");
  web.setWebChromeClient(new WebChromeClient());
  web.setWebViewClient(new WebViewClient(){
   @Override public boolean shouldOverrideUrlLoading(WebView v,WebResourceRequest r){
    Uri u=r.getUrl();if("127.0.0.1".equals(u.getHost()) && "http".equals(u.getScheme()))return false;
    try {startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception ignored){}return true;
   }
   @Override public void onPageStarted(WebView v,String url,android.graphics.Bitmap icon){if(url.startsWith(HOME))loadFailed=false;}
   @Override public void onPageFinished(WebView v,String url){if(!closed && url.startsWith(HOME) && !loadFailed){web.setVisibility(View.VISIBLE);status.setVisibility(View.GONE);}}
   @Override public void onReceivedError(WebView v,WebResourceRequest r,WebResourceError e){if(r.isForMainFrame()){loadFailed=true;web.setVisibility(View.INVISIBLE);status.setText("Server není dostupný. Klepni pro obnovení.");status.setVisibility(View.VISIBLE);}}
  });
  root.addView(web,new FrameLayout.LayoutParams(-1,-1));
  status=new TextView(this);status.setText("Spouštím TikTok Dashboard…");status.setTextColor(Color.WHITE);status.setTextSize(18);status.setGravity(Gravity.CENTER);status.setPadding(32,32,32,32);
  root.addView(status,new FrameLayout.LayoutParams(-1,-1));status.setOnClickListener(v->waitForServer());setContentView(root);
  if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
   requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},101);
  startDashboardService(null);
  waitForServer();
 }
 private void startDashboardService(String watch){
  try{Intent i=new Intent(this,DashboardService.class);if(watch!=null)i.putExtra("watch",watch);
   if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);
  }catch(Exception e){if(status!=null)status.setText("Nepodařilo se spustit službu: "+e.getMessage());}
 }
 private void waitForServer(){
  if(checking||closed)return;checking=true;status.setText("Čekám na spuštění lokálního serveru…");status.setVisibility(View.VISIBLE);
  checker.execute(()->{
   boolean ready=false;
   for(int i=0;i<90&&!closed;i++){
    HttpURLConnection c=null;
    try{c=(HttpURLConnection)new URL(HOME).openConnection();c.setConnectTimeout(700);c.setReadTimeout(700);c.setUseCaches(false);
     int code=c.getResponseCode();if(code>=200&&code<400){ready=true;break;}
    }catch(Exception ignored){}finally{if(c!=null)c.disconnect();}
    try{Thread.sleep(1000);}catch(InterruptedException e){break;}
   }
   final boolean found=ready;runOnUiThread(()->{checking=false;if(closed)return;
    if(found){status.setText("Načítám Dashboard…");web.loadUrl(HOME);}
    else status.setText("Server se nespustil do 90 sekund. Klepni pro další pokus.");
   });
  });
 }
 private class Bridge{
  @JavascriptInterface public void exportFile(String relativeUrl,String filename){
   if(relativeUrl==null || !relativeUrl.startsWith("/api/") || relativeUrl.contains("\n"))return;
   final String name=filename!=null && filename.matches("[A-Za-z0-9._-]{1,100}")?filename:"kushoven-export.jsonl";
   runOnUiThread(()->{
    exportPath=relativeUrl;
    Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
    intent.addCategory(Intent.CATEGORY_OPENABLE);
    intent.setType(name.endsWith(".json")?"application/json":"application/x-ndjson");
    intent.putExtra(Intent.EXTRA_TITLE,name);
    startActivityForResult(intent,EXPORT_REQUEST);
   });
  }
  @JavascriptInterface public void watch(String name){
   if(name==null||!name.matches("[A-Za-z0-9._]{1,40}"))return;
   getSharedPreferences("dashboard",MODE_PRIVATE).edit().putString("watched",name).apply();
   runOnUiThread(()->startDashboardService(name));
  }
  @JavascriptInterface public boolean isKeepAwake(){return getSharedPreferences("dashboard",MODE_PRIVATE).getBoolean("keep_awake",false);}
  @JavascriptInterface public void setKeepAwake(boolean on){getSharedPreferences("dashboard",MODE_PRIVATE).edit().putBoolean("keep_awake",on).apply();runOnUiThread(()->setScreenAwake(on));}
  @JavascriptInterface public boolean isBatteryExempt(){PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);return pm.isIgnoringBatteryOptimizations(getPackageName());}
  @JavascriptInterface public void requestBatteryExemption(){runOnUiThread(()->{try{startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));}catch(Exception ignored){}});}
  // --- Kondomek (AI duch v plovoucím okýnku) ---
  @JavascriptInterface public boolean canOverlay(){return Settings.canDrawOverlays(MainActivity.this);}
  @JavascriptInterface public void requestOverlay(){runOnUiThread(()->{try{startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())));}catch(Exception e){try{startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION));}catch(Exception ignored){}}});}
  @JavascriptInterface public boolean isKondomekShown(){return OverlayService.running;}
  @JavascriptInterface public String kondomekVoiceStatus(){return OverlayService.running?OverlayService.ttsStatus:"Hlas se zapne spolu s okýnkem.";}
  @JavascriptInterface public void showKondomek(String size){
   runOnUiThread(()->{
    if(!Settings.canDrawOverlays(MainActivity.this)){Toast.makeText(MainActivity.this,"Povol „Zobrazit přes jiné aplikace“ a pak ťukni znovu.",Toast.LENGTH_LONG).show();requestOverlay();return;}
    try{Intent i=new Intent(MainActivity.this,OverlayService.class);if(size!=null&&size.matches("[SML]"))i.putExtra("size",size);
     if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);
    }catch(Exception e){Toast.makeText(MainActivity.this,"Okýnko nejde spustit: "+e.getMessage(),Toast.LENGTH_LONG).show();}
   });
  }
  @JavascriptInterface public void hideKondomek(){runOnUiThread(()->stopService(new Intent(MainActivity.this,OverlayService.class)));}
  @JavascriptInterface public void openVoiceSettings(){runOnUiThread(()->{try{startActivity(new Intent("com.android.settings.TTS_SETTINGS"));}catch(Exception e){try{startActivity(new Intent(Settings.ACTION_SETTINGS));}catch(Exception ignored){}}});}
  @JavascriptInterface public void notify(String category,String title,String message){
   if(!"gifts".equals(category)&&!"questions".equals(category)&&!"mention".equals(category)&&!"watched".equals(category))return;
   if(title==null||message==null)return;
   DashboardService.showEvent(MainActivity.this,title,message);
  }
 }
 @Override protected void onActivityResult(int request,int result,Intent data){
  super.onActivityResult(request,result,data);
  if(request!=EXPORT_REQUEST||result!=RESULT_OK||data==null||data.getData()==null)return;
  final Uri destination=data.getData(); final String source=exportPath;
  checker.execute(()->{
   HttpURLConnection c=null;
   try{
    c=(HttpURLConnection)new URL("http://127.0.0.1:8000"+source).openConnection();
    c.setConnectTimeout(5000);c.setReadTimeout(15000);
    if(c.getResponseCode()!=200)throw new java.io.IOException("HTTP "+c.getResponseCode());
    try(java.io.InputStream in=c.getInputStream();java.io.OutputStream out=getContentResolver().openOutputStream(destination)){
     if(out==null)throw new java.io.IOException("Nelze otevřít cílový soubor");
     byte[] buf=new byte[8192];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);
    }
    runOnUiThread(()->Toast.makeText(this,"Soubor byl uložen",Toast.LENGTH_LONG).show());
   }catch(Exception e){runOnUiThread(()->Toast.makeText(this,"Export selhal: "+e.getMessage(),Toast.LENGTH_LONG).show());}
   finally{if(c!=null)c.disconnect();}
  });
 }
 private void setScreenAwake(boolean on){if(on)getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);}
 @Override protected void onResume(){super.onResume();getSharedPreferences("dashboard",MODE_PRIVATE).edit().putBoolean("visible",true).apply();setScreenAwake(getSharedPreferences("dashboard",MODE_PRIVATE).getBoolean("keep_awake",false));}
 @Override protected void onStart(){super.onStart();if(web!=null)web.evaluateJavascript("if(window.dashboardResume)window.dashboardResume();",null);}
 @Override protected void onPause(){getSharedPreferences("dashboard",MODE_PRIVATE).edit().putBoolean("visible",false).apply();super.onPause();}
 @Override public void onBackPressed(){
  if(web==null){super.onBackPressed();return;}
  web.evaluateJavascript("(function(){try{return window.onAndroidBack && window.onAndroidBack()?'yes':'no'}catch(e){return 'no'}})()",r->{if(!"\"yes\"".equals(r)){if(web.canGoBack())web.goBack();else MainActivity.super.onBackPressed();}});
 }
 @Override protected void onDestroy(){closed=true;checker.shutdownNow();if(web!=null){((android.view.ViewGroup)web.getParent()).removeView(web);web.destroy();}super.onDestroy();}
}
